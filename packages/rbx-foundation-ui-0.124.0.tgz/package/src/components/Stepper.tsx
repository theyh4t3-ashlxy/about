import clsx from 'clsx';
import React, { CSSProperties, useLayoutEffect, useRef } from 'react';
import type {
  TTailwindGapClass,
  TTailwindPaddingYClass,
  TTailwindTextBodyClass,
  TTailwindTextCaptionClass,
  TTailwindTextLabelClass,
  TTailwindTextTitleClass
} from '@rbx/foundation-tailwind/classes';
import { Icon, TIconSize } from './Icon';
import './internal/Common.css';
import { disabledOpacity } from '../utils/styles';

export const stepperSizes = ['Medium', 'Small', 'XSmall'] as const;
export type TStepperSize = (typeof stepperSizes)[number];

export const stepperBorderPositions = ['Top', 'Bottom'] as const;
export type TStepperBorderPosition = (typeof stepperBorderPositions)[number];

export type TStepperStepState = 'complete' | 'current' | 'upcoming' | 'disabled';

export type TStepperStep = {
  id?: string;
  label: string;
  description?: string;
  state?: TStepperStepState;
};

export type TStepperProps = {
  steps: TStepperStep[];
  currentStepIndex?: number;
  size?: TStepperSize;
  borderPosition?: TStepperBorderPosition;
  /** NOTE: Compact mode is not production-ready due to i18n requirements for hardcoded text. */
  isCompact?: false; // Will make this a boolean once i18n is supported
  showDescription?: boolean;
  className?: string;
  'aria-label'?: string;
};

type StepperItemState = Exclude<TStepperStepState, 'upcoming'> | 'upcoming';

const ICON_WRAPPER_STYLE: Record<TStepperSize, CSSProperties> = {
  Medium: { width: '30px', height: '30px' },
  Small: { width: '24px', height: '24px' },
  XSmall: { width: '24px', height: '24px' }
};

const ICON_INNER_STYLE: CSSProperties = { inset: '16.67%' };

const STEP_GAP: Record<TStepperSize, TTailwindGapClass> = {
  Medium: 'gap-small',
  Small: 'gap-small',
  XSmall: 'gap-xsmall'
};

const STEP_PADDING_Y: Record<TStepperSize, TTailwindPaddingYClass> = {
  Medium: 'padding-y-medium',
  Small: 'padding-y-small',
  XSmall: 'padding-y-xsmall'
};

const STEP_LABEL_TEXT: Record<TStepperSize, TTailwindTextTitleClass> = {
  Medium: 'text-title-medium',
  Small: 'text-title-small',
  XSmall: 'text-title-small'
};

const STEP_DESCRIPTION_TEXT: Record<TStepperSize, TTailwindTextBodyClass> = {
  Medium: 'text-body-medium',
  Small: 'text-body-small',
  XSmall: 'text-body-small'
};

const ICON_TEXT: Record<TStepperSize, TTailwindTextBodyClass> = {
  Medium: 'text-body-medium',
  Small: 'text-body-small',
  XSmall: 'text-body-small'
};

const COMPACT_TITLE: Record<TStepperSize, TTailwindTextLabelClass | TTailwindTextCaptionClass> = {
  Medium: 'text-label-medium',
  Small: 'text-label-small',
  XSmall: 'text-caption-small'
};

const COMPACT_DESCRIPTION: Record<
  TStepperSize,
  TTailwindTextBodyClass | TTailwindTextCaptionClass
> = {
  Medium: 'text-body-medium',
  Small: 'text-body-small',
  XSmall: 'text-caption-small'
};

const CHECK_ICON_SIZE: Record<TStepperSize, TIconSize> = {
  Medium: 'Medium',
  Small: 'Small',
  XSmall: 'Small'
};

const clampCurrentIndex = (index: number, total: number) => {
  if (total <= 0) return 0;
  if (index < 0) return 0;
  if (index >= total) return total - 1;
  return index;
};

const getBorderStyle = (
  borderPosition: TStepperBorderPosition,
  state: StepperItemState,
  size: TStepperSize
): CSSProperties => {
  const isCurrent = state === 'current';
  const pos = borderPosition === 'Top' ? 'top left' : 'bottom left';
  const baseWidth = 'var(--stroke-standard)';
  const baseColor = 'var(--color-stroke-default)';
  const baseGradient = `linear-gradient(${baseColor}, ${baseColor})`;

  if (!isCurrent) {
    return {
      backgroundImage: baseGradient,
      backgroundRepeat: 'no-repeat',
      backgroundSize: `100% ${baseWidth}`,
      backgroundPosition: pos
    };
  }

  const currentWidth = size === 'XSmall' ? 'var(--stroke-thick)' : 'var(--stroke-thicker)';
  const progressColor = 'var(--fui-future-alpha-color-system-progress)';

  return {
    backgroundImage: `linear-gradient(${progressColor}, ${progressColor}), ${baseGradient}`,
    backgroundRepeat: 'no-repeat',
    backgroundSize: `100% ${currentWidth}, 100% ${baseWidth}`,
    backgroundPosition: `${pos}, ${pos}`
  };
};

const getIconNode = (
  state: StepperItemState,
  index: number,
  size: TStepperSize
): React.ReactNode => {
  const outerWrapper = 'relative shrink-0';
  const innerCircleBase = 'absolute radius-circle flex items-center justify-center';

  if (state === 'complete') {
    return (
      <div className={outerWrapper} style={ICON_WRAPPER_STYLE[size]}>
        <div className={clsx(innerCircleBase, 'bg-system-contrast')} style={ICON_INNER_STYLE}>
          <Icon
            name='icon-filled-check'
            size={CHECK_ICON_SIZE[size]}
            className='content-inverse-emphasis'
          />
        </div>
      </div>
    );
  }

  if (state === 'current') {
    return (
      <div className={outerWrapper} style={ICON_WRAPPER_STYLE[size]}>
        <div
          className={clsx(innerCircleBase, 'bg-none stroke-system-contrast stroke-standard')}
          style={ICON_INNER_STYLE}>
          <span className={clsx(ICON_TEXT[size], 'content-emphasis leading-none')}>
            {index + 1}
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className={outerWrapper} style={ICON_WRAPPER_STYLE[size]}>
      <div className={clsx(innerCircleBase, 'bg-shift-300')} style={ICON_INNER_STYLE}>
        <span className={clsx(ICON_TEXT[size], 'content-default leading-none')}>{index + 1}</span>
      </div>
    </div>
  );
};

export const Stepper: React.FC<TStepperProps> = ({
  steps,
  currentStepIndex = 0,
  size = 'Medium',
  borderPosition = 'Bottom',
  isCompact,
  showDescription = true,
  className,
  'aria-label': ariaLabel
}) => {
  const scrollContainerRef = useRef<HTMLDivElement | null>(null);
  const stepRefs = useRef<Array<HTMLDivElement | null>>([]);
  const totalSteps = steps.length;
  const isFinished = currentStepIndex >= totalSteps;
  const safeCurrentIndex = clampCurrentIndex(currentStepIndex, totalSteps);

  useLayoutEffect(() => {
    if (totalSteps === 0 || isCompact) {
      return;
    }

    const step = stepRefs.current[safeCurrentIndex];

    if (step) {
      step.scrollIntoView({
        behavior: 'smooth',
        inline: 'center',
        block: 'nearest'
      });
    }
  }, [isCompact, safeCurrentIndex, totalSteps]);

  if (totalSteps === 0) return null;

  const computedSteps = steps.map((step, index) => {
    let derivedState: StepperItemState;
    if (step.state) {
      derivedState = step.state as StepperItemState;
    } else if (isFinished) {
      derivedState = 'complete';
    } else if (index < safeCurrentIndex) {
      derivedState = 'complete';
    } else if (index === safeCurrentIndex) {
      derivedState = 'current';
    } else {
      derivedState = 'upcoming';
    }

    return { ...step, state: derivedState };
  });

  stepRefs.current.length = totalSteps;

  if (isCompact) {
    const current = computedSteps[safeCurrentIndex];
    const progressLabel =
      ariaLabel ??
      `Step ${safeCurrentIndex + 1} of ${totalSteps}${current?.label ? `: ${current.label}` : ''}`;

    return (
      <div
        key='compact'
        className={clsx(
          'flex items-center gap-xsmall',
          COMPACT_TITLE[size],
          'content-default',
          className
        )}
        role='status'
        aria-live='polite'
        aria-label={progressLabel}>
        <span className='content-default'>Step</span>
        <div className='flex items-center gap-xxsmall content-default'>
          <span>{safeCurrentIndex + 1}</span>
          <span>/</span>
          <span>{totalSteps}</span>
        </div>
        {showDescription && current?.description && (
          <span className={clsx(COMPACT_DESCRIPTION[size], 'content-muted text-truncate-end')}>
            {current.description}
          </span>
        )}
      </div>
    );
  }

  return (
    <div
      key='full'
      ref={scrollContainerRef}
      className={clsx('flex width-full items-stretch scroll-x no-wrap', className)}
      style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
      role='list'
      aria-label={ariaLabel}>
      {computedSteps.map((step, index) => {
        const state = step.state as StepperItemState;
        const isDisabled = state === 'disabled';
        const isCurrent = state === 'current';
        const stepBorderStyle = getBorderStyle(borderPosition, state, size);
        const itemAriaLabel = `${index + 1} of ${totalSteps}: ${step.label}${
          step.description ? ` - ${step.description}` : ''
        }${isDisabled ? ' (disabled)' : ''}`;
        const stepKey = step.id ?? `${index}-${step.label}-${step.description ?? 'step'}`;

        return (
          <div
            key={stepKey}
            ref={element => {
              stepRefs.current[index] = element;
            }}
            role='listitem'
            aria-current={isCurrent ? 'step' : undefined}
            aria-setsize={totalSteps}
            aria-posinset={index + 1}
            aria-label={itemAriaLabel}
            className={clsx(
              'flex grow items-center',
              STEP_GAP[size],
              STEP_PADDING_Y[size],
              'stroke-default',
              { [disabledOpacity]: isDisabled }
            )}
            style={stepBorderStyle}>
            {getIconNode(state, index, size)}
            <div className='flex flex-col min-width-0 max-width-[250px] grow padding-right-medium'>
              <span
                className={clsx(
                  STEP_LABEL_TEXT[size],
                  isCurrent ? 'content-emphasis' : 'content-default',
                  'text-no-wrap',
                  'text-truncate-end'
                )}>
                {step.label}
              </span>
              {step.description && (
                <span
                  className={clsx(
                    STEP_DESCRIPTION_TEXT[size],
                    isCurrent ? 'content-emphasis' : 'content-default',
                    'text-no-wrap',
                    'text-truncate-end'
                  )}>
                  {step.description}
                </span>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
};