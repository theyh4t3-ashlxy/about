import clsx from 'clsx';
import React, { forwardRef } from 'react';
import type { TTailwindIconClass, TTailwindStrokeClass } from '@rbx/foundation-tailwind/classes';
import { Button } from './Button';
import { Icon } from './Icon';
import { Link } from './Link';
import { CloseAffordance } from './internal/CloseAffordance';
import { TForwardRefComponent } from './types/TForwardRefComponent';
import useId from '../utils/useId';

export const alertVariants = ['System', 'Feedback'] as const;
export type TAlertVariant = (typeof alertVariants)[number];

export const alertSeverities = ['Info', 'Warning', 'Success', 'Error'] as const;
export type TAlertSeverity = (typeof alertSeverities)[number];

type TAlertBaseProps = Omit<React.ComponentPropsWithRef<'div'>, 'children' | 'role'> & {
  /** The alert message. */
  children: React.ReactNode;
  /** Determines whether the alert is global or contextual. @default System */
  variant?: TAlertVariant;
  /** Determines the alert's meaning, icon, color, and announcement priority. @default Info */
  severity?: TAlertSeverity;
  /** The primary action label. */
  primaryActionLabel?: string;
  /** Called when the primary action is activated. */
  onPrimaryAction?: () => void;
  /** The secondary action label. A configured secondary action switches both actions to button treatment. */
  secondaryActionLabel?: string;
  /** Called when the secondary action is activated. */
  onSecondaryAction?: () => void;
};

type TAlertPrimaryActionLinkProps =
  | {
      /** Renders the primary action as a true link. */
      primaryActionHref?: string;
      primaryActionLinkTarget?: never;
    }
  | {
      primaryActionHref?: never;
      /** Uses a custom link element for navigation. Alert supplies its label and action treatment. */
      primaryActionLinkTarget: React.ReactElement;
    };

type TAlertSecondaryActionLinkProps =
  | {
      /** Renders the secondary action as a true link. */
      secondaryActionHref?: string;
      secondaryActionLinkTarget?: never;
    }
  | {
      secondaryActionHref?: never;
      /** Uses a custom link element for navigation. Alert supplies its label and action treatment. */
      secondaryActionLinkTarget: React.ReactElement;
    };

type TAlertCloseProps =
  | {
      /** Shows the dismiss affordance. @default true */
      hasCloseAffordance?: true;
      /** Accessible label for the dismiss affordance. @default Dismiss alert */
      closeLabel?: string;
      /** Called when the dismiss affordance is activated. */
      onDismiss: () => void;
    }
  | {
      hasCloseAffordance: false;
      closeLabel?: never;
      onDismiss?: never;
    };

export type TAlertProps = TAlertBaseProps &
  TAlertPrimaryActionLinkProps &
  TAlertSecondaryActionLinkProps &
  TAlertCloseProps;

const ICON_BY_SEVERITY: Record<TAlertSeverity, TTailwindIconClass> = {
  Info: 'icon-filled-circle-i',
  Warning: 'icon-filled-triangle-exclamation',
  Success: 'icon-filled-circle-check',
  Error: 'icon-filled-circle-x'
};

const ICON_COLOR_BY_SEVERITY: Record<TAlertSeverity, string> = {
  Info: 'var(--color-system-emphasis)',
  Warning: 'var(--color-system-warning)',
  Success: 'var(--color-extended-green-700, var(--color-system-success))',
  Error: 'var(--color-action-alert-foreground)'
};

const STROKE_CLASS_BY_SEVERITY: Record<TAlertSeverity, TTailwindStrokeClass> = {
  Info: 'stroke-emphasis',
  Warning: 'stroke-system-warning',
  Success: 'stroke-emphasis',
  Error: 'stroke-system-alert'
};

const BACKGROUND_COLOR_BY_SEVERITY: Record<TAlertSeverity, string> = {
  Info: 'rgb(from var(--color-system-neutral) r g b / 0.1)',
  Warning: 'rgb(from var(--color-system-warning) r g b / 0.16)',
  Success: 'rgb(from var(--color-system-success) r g b / 0.1)',
  Error: 'rgb(from var(--color-system-alert) r g b / 0.16)'
};

type TActionProps = {
  label: string;
  href?: string;
  linkTarget?: React.ReactElement;
  onAction?: () => void;
  variant: 'Standard' | 'Utility';
};

const ButtonAction = ({ label, href, linkTarget, onAction, variant }: TActionProps) => {
  if (linkTarget) {
    return (
      <Button asChild size='Small' variant={variant} onClick={onAction}>
        {React.cloneElement(linkTarget, {}, label)}
      </Button>
    );
  }

  if (href) {
    return (
      <Button as='a' href={href} size='Small' variant={variant} onClick={onAction}>
        {label}
      </Button>
    );
  }

  return (
    <Button size='Small' variant={variant} onClick={onAction}>
      {label}
    </Button>
  );
};

const LinkAction = ({ label, href, linkTarget, onAction }: Omit<TActionProps, 'variant'>) => {
  if (linkTarget) {
    return (
      // eslint-disable-next-line jsx-a11y/anchor-is-valid -- The child supplies link navigation.
      <Link asChild onClick={onAction} size='Medium' variant='Standalone' underline='always'>
        {React.cloneElement(linkTarget, {}, label)}
      </Link>
    );
  }

  if (href) {
    return (
      <Link href={href} onClick={onAction} size='Medium' variant='Standalone' underline='always'>
        {label}
      </Link>
    );
  }

  return (
    // eslint-disable-next-line jsx-a11y/anchor-is-valid -- Link renders a button for this variant.
    <Link as='button' onClick={onAction} size='Medium' variant='Standalone' underline='always'>
      {label}
    </Link>
  );
};

const AlertComponent = (
  {
    children,
    variant = 'System',
    severity = 'Info',
    primaryActionLabel,
    primaryActionHref,
    primaryActionLinkTarget,
    onPrimaryAction,
    secondaryActionLabel,
    secondaryActionHref,
    secondaryActionLinkTarget,
    onSecondaryAction,
    hasCloseAffordance = true,
    closeLabel = 'Dismiss alert',
    onDismiss,
    className,
    style,
    ...rest
  }: TAlertProps,
  ref: React.ComponentPropsWithRef<'div'>['ref']
) => {
  const messageId = useId('foundation-web-alert-message-');

  const hasPrimaryAction = Boolean(primaryActionLabel);
  const hasSecondaryAction = Boolean(secondaryActionLabel);
  const hasDismissAction = Boolean(hasCloseAffordance && onDismiss);

  const hasInteractiveFeedback =
    variant === 'Feedback' && (hasPrimaryAction || hasSecondaryAction || hasDismissAction);
  const messageRole = severity === 'Warning' || severity === 'Error' ? 'alert' : 'status';

  let primaryAction: React.ReactNode = null;
  if (hasPrimaryAction) {
    if (hasSecondaryAction) {
      primaryAction = (
        <ButtonAction
          label={primaryActionLabel || ''}
          href={primaryActionHref}
          linkTarget={primaryActionLinkTarget}
          onAction={onPrimaryAction}
          variant='Standard'
        />
      );
    } else {
      primaryAction = (
        <LinkAction
          label={primaryActionLabel || ''}
          href={primaryActionHref}
          linkTarget={primaryActionLinkTarget}
          onAction={onPrimaryAction}
        />
      );
    }
  }

  const secondaryAction = hasSecondaryAction ? (
    <ButtonAction
      label={secondaryActionLabel || ''}
      href={secondaryActionHref}
      linkTarget={secondaryActionLinkTarget}
      onAction={onSecondaryAction}
      variant='Utility'
    />
  ) : null;

  return (
    <div
      ref={ref}
      role={hasInteractiveFeedback ? 'region' : messageRole}
      aria-labelledby={hasInteractiveFeedback ? messageId : undefined}
      className={clsx(
        'foundation-web-alert relative width-full stroke-standard',
        variant === 'System' ? '[border-left-width:0] [border-right-width:0]' : 'radius-medium',
        STROKE_CLASS_BY_SEVERITY[severity],
        className
      )}
      style={style}
      {...rest}>
      <div
        aria-hidden='true'
        className={clsx(
          'absolute inset-[0] pointer-events-none',
          variant === 'Feedback' && 'radius-medium'
        )}
        style={{
          backgroundColor: BACKGROUND_COLOR_BY_SEVERITY[severity]
        }}
      />
      <div className='relative flex items-start gap-x-medium padding-x-large padding-y-small min-width-0'>
        <div className='flex items-start padding-y-xsmall self-stretch shrink-0'>
          <div className='relative flex items-start padding-y-xxsmall'>
            {severity !== 'Warning' && (
              // This is to allow icons to have a white inner color for all variants
              <span
                aria-hidden='true'
                className='absolute width-[10px] height-[14px] top-[5px]'
                style={{
                  left: '50%',
                  transform: 'translateX(-50%)',
                  backgroundColor: 'var(--dark-mode-content-emphasis)'
                }}
              />
            )}
            <Icon
              aria-hidden='true'
              name={ICON_BY_SEVERITY[severity]}
              size='Medium'
              className='relative'
              style={{ color: ICON_COLOR_BY_SEVERITY[severity] }}
            />
          </div>
        </div>
        <div
          className={clsx(
            'flex grow-1 basis-0 min-width-0 items-start gap-x-medium gap-y-small',
            hasSecondaryAction ? 'flex-col' : 'wrap'
          )}>
          <div
            id={hasInteractiveFeedback ? messageId : undefined}
            role={hasInteractiveFeedback ? messageRole : undefined}
            className={clsx(
              'flex items-center padding-top-[var(--size-150)] text-body-medium content-emphasis [overflow-wrap:anywhere]',
              hasSecondaryAction
                ? 'width-full min-width-0'
                : 'grow-1 basis-0 min-width-[min(200px,100%)]'
            )}>
            {children}
          </div>
          {(primaryAction || secondaryAction) && (
            <div
              className={clsx(
                'flex items-center gap-small shrink-0',
                !hasSecondaryAction && 'padding-y-[var(--size-150)]'
              )}>
              {primaryAction}
              {secondaryAction}
            </div>
          )}
        </div>
        {hasDismissAction && (
          <CloseAffordance
            variant='Utility'
            size='Medium'
            isCircular
            className='content-emphasis shrink-0 padding-[var(--size-150)]'
            aria-label={closeLabel}
            onClick={onDismiss}
          />
        )}
      </div>
    </div>
  );
};

export const Alert = forwardRef(AlertComponent) as TForwardRefComponent<TAlertProps>;